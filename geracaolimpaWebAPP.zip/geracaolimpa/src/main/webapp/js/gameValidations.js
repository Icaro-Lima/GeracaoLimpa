$('.divGame').hide();

var lista = [];
var resultado = [];
var imgAtual = 0;
function imagens(imagensCidadania) {
	$.ajax({
		url : 'imagensCidadania',
		type : 'POST',
		dataType : "json",
		success : function(data) {
			;
			lista = data.list;
			$('.divGame').show();
			$('#img-game').attr('src', lista[imgAtual]);
		},
		error : function(data) {
			console.log("ERRO");
		}
	});
}

function computaResultado(arr, resposta) {
	arr.push(resposta);
	if (arr.length == lista.length) {
		// Teste terminou
		console.log(resultado);
		console.log(lista);
		$('.divGame').hide();
		return;
	}
	imgAtual++;
	$('#img-game').attr('src', lista[imgAtual]);
}
$('#botao-Sim').click(function() {
	computaResultado(resultado, "sim");
});

$('#botao-Nao').click(function() {
	computaResultado(resultado, "nao");
});
