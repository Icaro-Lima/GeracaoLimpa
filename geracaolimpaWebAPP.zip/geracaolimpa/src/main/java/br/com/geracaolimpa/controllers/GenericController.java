package br.com.geracaolimpa.controllers;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.vraptor.Result;
import br.com.geracaolimpa.util.Sessao;

public class GenericController {
	
	@Inject
	protected Sessao sessao;
	@Inject
	protected Result result;
	@Inject
	protected HttpServletResponse response;
	@Inject
	protected HttpServletRequest request;
	
	
}
