package br.com.geracaolimpa.controllers;

import java.util.Arrays;
import java.util.List;

import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Get;
import br.com.caelum.vraptor.Post;
import br.com.caelum.vraptor.view.Results;

@Controller
public class JogarController extends GenericController{
	
	@Get("/jogoTransito")
	public void transitoGame(){
		 
	}

	@Post("/imagensTransito")
	public void imagensTransito(){
		response.setContentType("JSON");
		
		List<String> imagensTransito = Arrays.asList("img/portfolio/bike.jpg", "img/portfolio/faixa.jpg", "img/portfolio/semcinto.jpg");
		
		result.use(Results.json()).from(imagensTransito).serialize();
	}
	
	/*@Get("/jogoTransito")
	public void transitoGame(){
		
	}*/
	
	@Get("/jogoConvivencia")
	public void convivenciaGame(){
		
	}
}
