package br.com.geracaolimpa.controllers;

import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Get;

@Controller
public class IndexController extends GenericController{
	
	@Get("/menuPrincipal")
	public void menuPrincipal() {	}
}
